export class StudentModel{
  id:number=0;
  name:string="";
  roll:number=0;
  email:string="";
  mobile:number=0;
  salary:number=0;
}
